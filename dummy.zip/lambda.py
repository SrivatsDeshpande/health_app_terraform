def lambda_handler():
    print("hello world")